import styled from "styled-components";

export const StyledPageHeader = styled.div`
  align-items: center;
  display: flex;
  height: 64px;
  width: 100%;
`