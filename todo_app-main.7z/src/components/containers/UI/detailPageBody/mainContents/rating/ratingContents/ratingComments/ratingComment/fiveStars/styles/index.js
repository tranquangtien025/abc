import styled from "styled-components"

export const StyledDiv7 = styled.div`
  display: inline-block;  
`

export const StyledStar = styled.span`
  height: 12px;
  width: 12px;
  display: inline-block;
  text-align: left;
`

export const StyledSpan2 = styled.span`
  color: #c71c56;
`