import { StyleButton, StyledDiv1, StyleSpan } from "./styles"

export const AllComments = () => {
  return (
    <div>
      <div>
        <StyledDiv1>
          <StyleButton>
            <StyleSpan>Xem tất cả bài đánh giá</StyleSpan>
          </StyleButton>
        </StyledDiv1>
      </div>
    </div>
  )
}