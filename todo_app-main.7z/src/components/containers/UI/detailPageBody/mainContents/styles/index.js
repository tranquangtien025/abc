import styled from "styled-components"

export const StyledMainContents = styled.div`
  @media screen and (min-width: 960px) {
    width: calc(100% - 312px - 36px);
  }
`