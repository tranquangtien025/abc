import { StyledContentTitle } from "./styles"

export const ContentTitle = (props: any) => {
  return (
    <StyledContentTitle>{props.title}</StyledContentTitle>
  )
}