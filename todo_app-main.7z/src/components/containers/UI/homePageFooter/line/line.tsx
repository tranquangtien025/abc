import { StyledLine } from "./styles"

export const Line = () => {
  return (
    <StyledLine />
  )
}