import styled from "styled-components";

export const StyledLine = styled.div`
  border-bottom: 1px solid rgb(232,234,237);
  margin-bottom: 36px;
  padding-top: 36px;
  width: 100%;
`