import styled from "styled-components";

export const StyledInfos = styled.div`
  margin-top: 32px;
  display: flex;
  flex-wrap: wrap;
`