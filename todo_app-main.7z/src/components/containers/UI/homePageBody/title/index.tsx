import { StyledText, StyledTitle } from "./styles"

export const Title = () => {
  return (
    <StyledTitle>
      <StyledText>Bảng xếp hạng hàng đầu</StyledText>
    </StyledTitle>
  )
}