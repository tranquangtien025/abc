import styled from "styled-components";

export const StyledThumbnail = styled.img`
  border-width: 0;
  border-radius: 4px;
  height: 96px;
  width: 72px;
`