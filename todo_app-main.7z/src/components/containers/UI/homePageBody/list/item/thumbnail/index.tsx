import { StyledThumbnail } from "./styles"

export const Thumbnail = (props: any) => {
  return (
    <StyledThumbnail src={props.thumbnail} />
  )
}